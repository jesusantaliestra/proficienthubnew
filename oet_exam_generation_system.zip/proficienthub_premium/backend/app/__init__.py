"""
ProficientHub Premium Backend App
=================================
B2B exam preparation platform with OET exam generation.
"""

__version__ = "1.0.0"
